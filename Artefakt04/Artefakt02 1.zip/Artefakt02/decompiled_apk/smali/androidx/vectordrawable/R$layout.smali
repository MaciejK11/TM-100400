.class public final Landroidx/vectordrawable/R$layout;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/vectordrawable/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final notification_action:I = 0x7f0b00b0

.field public static final notification_action_tombstone:I = 0x7f0b00b1

.field public static final notification_template_custom_big:I = 0x7f0b00b2

.field public static final notification_template_icon_group:I = 0x7f0b00b3

.field public static final notification_template_part_chronometer:I = 0x7f0b00b4

.field public static final notification_template_part_time:I = 0x7f0b00b5


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 132
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
