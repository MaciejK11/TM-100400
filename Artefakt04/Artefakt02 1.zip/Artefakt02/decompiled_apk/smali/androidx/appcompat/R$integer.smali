.class public final Landroidx/appcompat/R$integer;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "integer"
.end annotation


# static fields
.field public static final abc_config_activityDefaultDur:I = 0x7f0a0000

.field public static final abc_config_activityShortDur:I = 0x7f0a0001

.field public static final cancel_button_image_alpha:I = 0x7f0a0002

.field public static final config_tooltipAnimTime:I = 0x7f0a0003

.field public static final status_bar_notification_info_maxnum:I = 0x7f0a0004


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 729
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
